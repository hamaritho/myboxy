import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Iterator; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class myboxy extends PApplet {

/******************************************************************************
 * Helper Functions                                                           *
 ******************************************************************************/
public void writeText(String t, int x, int y, float fontsize) {
	textFont(f, fontsize);
	text(t, x, y);
}

public void writeText(char[] t, int x, int y, float fontsize) {
	textFont(f, fontsize);

	for (char letter : t) {
		text(letter, x, y);
		x += 50;
	}
}

/******************************************************************************
 * Running the Game                                                           *
 ******************************************************************************/
PFont f;
Game game;

public void setup() {
	size(600,600);
	f = createFont("Ubuntu Mono", 77);
	rectMode(CENTER);
	textAlign(CENTER, CENTER);
	game = new Game();
}

public void draw() {
	game.draw();
}

public void mouseClicked(MouseEvent event) {
	game.mousePressed(event);
}

public void mouseDragged(MouseEvent event) {
	game.mousePressed(event);
}

public void keyPressed() {
	if (key == ESC) {
		exit();
	}
}
class BounceState implements BoxyState {

	private Boxy boxy;
	private int bounceHeight;
	private int stride;
	private int direction;

	public BounceState(Boxy boxy) {
		this.boxy = boxy;
		direction = -1;
		stride = 1;
		bounceHeight = boxy.getMaxY() - 5;
	}

	public void update() {
		boxy.changeY(direction * stride);

		if (boxy.getY() < bounceHeight) {
			direction *= -1;
			boxy.setPosition(boxy.getX(), bounceHeight);
		} else if (boxy.getY() > boxy.getMaxY()) {
			direction *= -1;
			boxy.setPosition(boxy.getX(), boxy.getMaxY());
			boxy.setState(boxy.getIdleState());
		}
	}

	public boolean isIdle() {
		return false;
	}
}
/******************************************************************************
 * Boxy                                                                       *
 ******************************************************************************/
class Boxy {

	//Interaction Values--------------------------------------------------------
	private int responsiveness;
	private final int MIN_RESPONSIVENESS = 1;
	private final int MAX_RESPONSIVENESS = 10;

	private int closeness;
	private final int MIN_CLOSENESS = 1;
	private final int MAX_CLOSENESS = 10;

	private int fullness;
	private final int MIN_FULLNESS = 0;
	private final int MAX_FULLNESS = 100;
	private final int FULLNESS_INCREASE_DELTA = 10;
	private final int FULLNESS_DECREASE_DELTA = 1;

	private int happiness;
	private final int MIN_HAPPINESS = 0;
	private final int MAX_HAPPINESS = 100;
	private final int HAPPINESS_DELTA = 10;

	private int reactionValue;

	private int sadTime;
	private int MAX_SADTIME = 1000;
	private int happyTime;
	private int MAX_HAPPYTIME = 1000;

	private final int DELTA = 1;

	private boolean likesPetting;

	//Properties----------------------------------------------------------------
	private String name;
	private int c;

	private final int LENGTH = 100;

	private int x;
	private final int MIN_X = LENGTH / 2;
	private final int MAX_X = width-LENGTH;
	
	private int y;
	private final int MIN_Y = LENGTH / 2;
	private final int MAX_Y = height-LENGTH;

	//Animation-----------------------------------------------------------------
	private int dragTime;
	private final int MAX_DRAGTIME = 50;

	private int stillTime;
	private final int MAX_STILLTIME = 150;

	private int noInteractionTime;
	private final int MAX_NOINTERACTIONTIME = 500;

	private BoxyState jumpState;
	private BoxyState slideState;
	private BoxyState bounceState;
	private BoxyState shakeState;
	private BoxyState idleState;
	private BoxyState currentState;

	//Constructor---------------------------------------------------------------
	public Boxy() {
		//Interaction Values
		responsiveness = PApplet.parseInt(random(MIN_RESPONSIVENESS,MAX_RESPONSIVENESS));
		closeness = PApplet.parseInt(random(MIN_CLOSENESS, MAX_CLOSENESS));
		fullness = PApplet.parseInt(random(MIN_FULLNESS, MAX_FULLNESS));
		happiness = PApplet.parseInt(random(MIN_HAPPINESS, MAX_HAPPINESS));

		reactionValue = responsiveness * closeness;
		sadTime = 0;
		happyTime = 0;

		likesPetting = random(100) > 50;

		//Properties
		name = "Boxy";
		c = color(PApplet.parseInt(random(255)), PApplet.parseInt(random(255)), PApplet.parseInt(random(255)));
		x = width / 2;
		y = MAX_Y;

		//Animation
		jumpState = new JumpState(this);
		slideState = new SlideState(this);
		bounceState = new BounceState(this);
		shakeState = new ShakeState(this);
		idleState = new IdleState(this);
		currentState = idleState;

		dragTime = 0;

		stillTime = 0;
	}

	//Draw----------------------------------------------------------------------
	public void draw() {
		fill(c);		
		rect(x, y, LENGTH, LENGTH);

		tick();
	}

	//Tick----------------------------------------------------------------------
	public void tick() {
		decreaseFullness();
		increaseNoInteractionTime();
		updateHappiness();
		updateCloseness();
		updateReactionValue();
		updateAction();
		currentState.update();
 	}

 	//Getters, Setters, and Modifiers
 	public boolean getLikesPetting() {
 		return likesPetting;
 	}

 	public void setLikesPetting(boolean likes) {
 		likesPetting = likes;
 	}

	public String getName() {
		return name;
	}

	public void setName(char[] letters) {
		name = "";
		for (char letter : letters) {

			if (letter != '_') {
				name += letter;
			}

		}
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getColor() {
		return c;
	}

	public void setColor(int c) {
		this.c = c;
	}

	public int getResponsiveness() {
		return responsiveness;
	}

	public void setResponsiveness(int r) {
		responsiveness = r;
	}

	public int getCloseness() {
		return closeness;
	}

	public void setCloseness(int c) {
		closeness = c;
	}

	public void decreaseCloseness() {
		if (closeness > MIN_CLOSENESS) {
			closeness -= DELTA;
		}
	}

	public void increaseCloseness() {
		if (closeness < MAX_CLOSENESS) {
			closeness += DELTA;
		}
	}

	public void updateCloseness() {
		if (sadTime > MAX_SADTIME && closeness > MIN_CLOSENESS) {

			zeroSadTime();
			decreaseCloseness();

		}
		else if (happyTime > MAX_HAPPYTIME && closeness < MAX_CLOSENESS) {

			zeroHappyTime();
			increaseCloseness();

		}
	}

	public int getFullness() {
		return fullness;
	}

	public void setFullness(int f) {
		fullness = f;
	}

	public void decreaseFullness() {
		if (fullness > MIN_FULLNESS && frameCount % 420 == 0) {
			fullness -= FULLNESS_DECREASE_DELTA;
		}
		if (fullness < MIN_FULLNESS) {
			fullness = MIN_FULLNESS;
		}
	}

	public void increaseFullness() {
		if (fullness < MAX_FULLNESS) {
			fullness += FULLNESS_INCREASE_DELTA;
		}
		if (fullness > MAX_FULLNESS) {
			fullness = MAX_FULLNESS;
		}
	}

	public int getHappiness() {
		return happiness;
	}

	public void setHappiness(int h) {
		happiness = h;
	}

	public void zeroHappiness() {
		happiness = 0;
	}

	public void halfHappiness() {
		happiness = MAX_HAPPINESS / 2;
	}

	public void decreaseHappiness() {
		if (happiness > MIN_HAPPINESS) {
			happiness -= HAPPINESS_DELTA;			
		}
	}

	public void increaseHappiness() {
		if (happiness < MAX_HAPPINESS) {
			happiness += HAPPINESS_DELTA;
		}
	}

	public void updateHappiness() {
		if (fullness < MAX_FULLNESS / 4) {
			zeroHappiness();

		} else if (fullness < MAX_FULLNESS / 2) {

			if (happiness > MAX_HAPPINESS / 2) {
				halfHappiness();
			} else {
				decreaseHappiness();
			}
		} else if (noInteractionTime > MAX_NOINTERACTIONTIME) {
			zeroNoInteractionTime();
			decreaseHappiness();
		}

		if (happiness < MAX_HAPPINESS / 2) {
			increaseSadTime();

		}
		else {
			increaseHappyTime();

		}
	}

	public void zeroSadTime() {
		sadTime = 0;
	}

	public void increaseSadTime() {
		sadTime += DELTA;
	}

	public void zeroHappyTime() {
		happyTime = 0;
	}

	public void increaseHappyTime() {
		happyTime += DELTA;
	}

	 public int getX() {
		return x;
	}

	public void changeX(int delta) {
		x += delta;
	}

	public int getY() {
		return y;
	}

	public void changeY(int delta) {
		y += delta;
	}

	public void setPosition(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public int getLength() {
		return LENGTH;
	}

	public int getReactionValue() {
		return reactionValue;
	}

	public void updateReactionValue() {
		reactionValue = responsiveness * closeness;
	}

	public void zeroNoInteractionTime() {
		noInteractionTime = 0;
	}

	public void increaseNoInteractionTime() {
		noInteractionTime += DELTA;
	}

	public boolean theMostHappy() {
		return happiness >= MAX_HAPPINESS * 0.9f;
	}

	public boolean theSaddest() {
		return happiness <= MAX_HAPPINESS * 0.1f;
	}

	public void mouseEvent(MouseEvent event) {
		int mx = event.getX();
		int my = event.getY();
		int left = x - (LENGTH / 2);
		int right = x + (LENGTH / 2);
		int top = y - (LENGTH / 2);
		int bottom = y + (LENGTH / 2);

		if (mx >= left && mx <= right && my >= top && my <= bottom) {
			switch(event.getAction()) {
				case MouseEvent.CLICK:
					if (likesPetting) {
						decreaseHappiness();
						
						if (currentState.isIdle()) {
							currentState = slideState;
						}
					} else {
						increaseHappiness();

						if (currentState.isIdle()) {
							currentState = jumpState;
						}
					}
					break;
				case MouseEvent.DRAG:
					dragTime += DELTA;

					if (dragTime > MAX_DRAGTIME) {
						if (likesPetting) {
							increaseHappiness();

							dragTime = 0;
							if (currentState.isIdle()) {
								currentState = jumpState;
							}
						} else {
							decreaseHappiness();

							dragTime = 0;
							if (currentState.isIdle()) {
								currentState = slideState;
							}
						}
					}
					break;
				default:
					break;
			}
			zeroNoInteractionTime();
		}
	}

	public void feed() {
		if (fullness >= MAX_FULLNESS) {
			decreaseHappiness();

			if (currentState.isIdle()) {
				currentState = slideState;
			}
		} else {
			increaseHappiness();

			if (currentState.isIdle()) {
				currentState = jumpState;
			}
		}
		increaseFullness();
		
	}

	public void updateAction() {
		if (currentState.isIdle()) {
			stillTime += DELTA;
			if(stillTime > MAX_STILLTIME) {
				if (happiness > MAX_HAPPINESS / 2) {
					currentState = bounceState;
				} else {
					currentState = shakeState;
				}
			}
		} else {
			stillTime = 0;
		}
	}

	public BoxyState getJumpState() {
		return jumpState;
	}

	public BoxyState getSlideState() {
		return slideState;
	}

	public BoxyState getBounceState() {
		return bounceState;
	}

	public BoxyState getShakeState() {
		return shakeState;
	}

	public BoxyState getIdleState() {
		return idleState;
	}

	public void setState(BoxyState state) {
		currentState = state;
	}

	public int getMaxY() {
		return MAX_Y;
	}
};
interface BoxyState {
	public void update();
	public boolean isIdle();
}
/******************************************************************************
 * Button Classes                                                             *
 ******************************************************************************/
class Button {
	String t;
	int x;
	int y;
	int w;
	int h;

	public Button(String t, int x, int y, int w, int h) {
		this.t = t;
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}

	public void draw() {
		fill(255);
		rect(x, y, w, h, 20);
		fill(0);
		writeText(t, x, y, 28.9f);
	}

	public boolean mouseEvent(MouseEvent event) {
		int mx = event.getX();
		int my = event.getY();
		int left = x - (w / 2);
		int right = x + (w / 2);
		int top = y - (h / 2);
		int bottom = y + (h / 2);

		switch(event.getAction()) {
			case MouseEvent.CLICK:
				return (mx >= left) && (mx <= right) && (my >= top) && (my <= bottom);
			default:
				return false;
		}
	}
};
class ColorButton extends Button {
	private int c;

	public ColorButton(int x, int y, int w, int h, int c) {
		super("", x, y, w, h);
		this.c = c;
	}

	public int getColor() {
		return c;
	}

	public void draw() {
		fill(c);
		rect(x, y, w, h);
	}
};
/******************************************************************************
 * FoodPellet                                                                 *
 ******************************************************************************/
 class FoodPellet {
 	private int y;
 	private int length = 5;
 	private int deg = 0;

 	public FoodPellet(int y) {
 		this.y = y;
 	}

 	public void draw(int x) {
 		fill(139,69,19);
 		pushMatrix();
 		translate(x, y);
 		rotate(radians(deg));
 		rect(0, 0, length, length);
 		popMatrix();

 		y += 3;
 		deg += 5;
 		deg %= 360;
 	}

 	public boolean isEaten(int by) {
 		return y >= by;
 	}
 };
/******************************************************************************
 * The Game                                                                   *
 ******************************************************************************/
class Game {
	private State titleState;
	private State newGameState;
	private State inGameState;
	private State howToPlayState;
	private State surveyState;

	private State state;

	private Boxy boxy;

	public Game() {
		boxy = new Boxy();
		titleState = new TitleState(this);
		newGameState = new NewGameState(this);
		inGameState = new InGameState(this);
		howToPlayState = new HowToPlayState(this);
		surveyState = new SurveyState(this);
		

		titleState.initializeItems();
		newGameState.initializeItems();
		inGameState.initializeItems();
		howToPlayState.initializeItems();
		surveyState.initializeItems();

		state = titleState;
	}

	public void draw() {
		state.draw();
	}

	public void mousePressed(MouseEvent event) {
		state.mouseEvent(event);
	}

	public State getTitleState() {
		return titleState;
	}

	public State getNewGameState() {
		return newGameState;
	}

	public State getInGameState() {
		return inGameState;
	}

	public State getHowToPlayState() {
		return howToPlayState;
	}

	public State getSurveyState() {
		return surveyState;
	}

	public void setState(State s) {
		state = s;
	}

	public Boxy getBoxy() {
		return boxy;
	}
};
/******************************************************************************
 * How To Play                                                                *
 ******************************************************************************/
class HowToPlayState implements State {
	private Game g;
	private PImage img; 
	private Button backButton;

	public HowToPlayState(Game g) {
		this.g = g;
		img = loadImage("howtoplay.png");
	}

	public void initializeItems() {
		backButton = new MenuButton("Main Menu", width / 2, height-37, 300, 50, g.getTitleState());
	}

	public void draw() {
		image(img, 0, 0);
		backButton.draw();
	}

	public void mouseEvent(MouseEvent event) {
		if (backButton.mouseEvent(event)) {
			g.setState(((MenuButton)backButton).getNextState());
		}
	}
};
class IdleState implements BoxyState {

	private Boxy boxy;

	public IdleState(Boxy boxy) {
		this.boxy = boxy;
	}

	public void update() {
	}

	public boolean isIdle() {
		return true;
	}
}


/******************************************************************************
 * In Game State                                                              *
 ******************************************************************************/
class InGameState implements State {
	private Game g;
	private Boxy b;
	private ArrayList<FoodPellet> foodPellets;
	private Button feedButton;
	private Button saveButton;
	private Button surveyButton;
	private boolean saved;

	public InGameState(Game g) {
		this.g = g;
		foodPellets = new ArrayList<FoodPellet>();
		feedButton = new Button("Feed", width-75, height / 2 + 100, 100, 50);
		saveButton = new Button("Save", width-75, height/2 - 100 , 100, 50);
		surveyButton = new Button("Take\nSurvey", width-75, height/2, 100, 100);
		saved = false;
		b = g.getBoxy();
	}

	public void initializeItems() {
	}

	public void draw() {
		background(255);
		fill(0);
		writeText(b.getName(), width / 2, 45, 77.7f);

		feedButton.draw();
		saveButton.draw();
		surveyButton.draw();

		if(!foodPellets.isEmpty()) {
			for (Iterator<FoodPellet> iterator = foodPellets.iterator(); iterator.hasNext();) {
			    FoodPellet pellet = iterator.next();
			    pellet.draw(b.getX());
			    if (pellet.isEaten(b.getY() - (b.getLength() / 2))) {
			    	b.feed();
			        // Remove the current element from the iterator and the list.
			        iterator.remove();
			    }
			}
		}

		if (b.theMostHappy()) {
			int c = b.getColor();
			fill(255-red(c), 255-blue(c), 255 - green(c));
			pushMatrix();
			translate(b.getX(), b.getY());
			rotate(frameCount / 40.0f);
			star(0, 0, 80, 100, 20);
			popMatrix();
			b.draw();
		}
		else if (b.theSaddest()) {
			b.draw();
			filter(GRAY);
		}
		else {
			b.draw();
		}

		fill(200);
		rect(width / 2, 575, width, 50);

		if (saved) {
			fill(255);
			rect(width/2, height/2, width-10, height-10);
			fill(0);
			writeText("Your game has been saved.\n You may now leave the game.", width/2, height/2, 28);
		}
	}

	public void mouseEvent(MouseEvent event) {
		b.mouseEvent(event);
		if (feedButton.mouseEvent(event)) {
			foodPellets.add(new FoodPellet(b.getY() - (height / 2)));
		}
		if (saveButton.mouseEvent(event)) {
			save();
			saved = true;
		}
		if (surveyButton.mouseEvent(event)) {
			link("http://goo.gl/forms/ZhJ8HLMxw4");
		}
	}

	public void star(float x, float y, float radius1, float radius2, int npoints) {
	  float angle = TWO_PI / npoints;
	  float halfAngle = angle/2.0f;
	  beginShape();
	  for (float a = 0; a < TWO_PI; a += angle) {
	    float sx = x + cos(a) * radius2;
	    float sy = y + sin(a) * radius2;
	    vertex(sx, sy);
	    sx = x + cos(a+halfAngle) * radius1;
	    sy = y + sin(a+halfAngle) * radius1;
	    vertex(sx, sy);
	  }
	  endShape(CLOSE);
	}

	public void save() {
		String[] data = {
			b.getName(),
			"" + b.getColor(),
			"" + b.getResponsiveness(),
			"" + b.getCloseness(),
			"" + b.getFullness(),
			"" + b.getHappiness(),
			"" + b.getLikesPetting()
		};

		saveStrings(dataFile("savegame.txt"), data);
	}
};
class JumpState implements BoxyState {

	private Boxy boxy;
	private int jumpHeight;
	private int stride;
	private int direction;

	public JumpState(Boxy boxy) {
		this.boxy = boxy;
		jumpHeight = boxy.getMaxY() - boxy.getReactionValue();
		stride = boxy.getReactionValue() / 10;
		direction = -1;
	}

	public void update() {
		boxy.changeY(stride * direction);

		if (boxy.getY() < jumpHeight) {
			direction *= -1;
			boxy.setPosition(boxy.getX(), jumpHeight);
		}
		else if (boxy.getY() > boxy.getMaxY()) {
			direction *= -1;
			boxy.setPosition(boxy.getX(), boxy.getMaxY());
			boxy.setState(boxy.getIdleState());
		}

		jumpHeight = boxy.getMaxY() - boxy.getReactionValue();
		stride = boxy.getReactionValue() / 10;
	}

	public boolean isIdle() {
		return false;
	}
}
class Key extends Button {
	private char letter;

	public Key(String t, int x, int y, int w, int h, char letter) {
		super(t, x, y, w, h);
		this.letter = letter;
	}

	public char getLetter() {
		return letter;
	}
};
/******************************************************************************
 * Keyboard Class                                                             *
 ******************************************************************************/
class Keyboard {
	private int startX;
	private int startY;
	private Key[] keys;
	private Key backspace;

	public Keyboard(int startX, int startY) {
		this.startX = startX;
		this.startY = startY;
		keys = new Key[26];

		keys[0] = new Key("Q", startX + 0, startY + 0, 50, 50, 'Q');
		keys[1] = new Key("W", startX + 50, startY + 0, 50, 50, 'W');
		keys[2] = new Key("E", startX + 100, startY + 0, 50, 50, 'E');
		keys[3] = new Key("R", startX + 150, startY + 0, 50, 50, 'R');
		keys[4] = new Key("T", startX + 200, startY + 0, 50, 50, 'T');
		keys[5] = new Key("Y", startX + 250, startY + 0, 50, 50, 'Y');
		keys[6] = new Key("U", startX + 300, startY + 0, 50, 50, 'U');
		keys[7] = new Key("I", startX + 350, startY + 0, 50, 50, 'I');
		keys[8] = new Key("O", startX + 400, startY + 0, 50, 50, 'O');
		keys[9] = new Key("P", startX + 450, startY + 0, 50, 50, 'P');

		keys[10] = new Key("A", startX + 25, startY + 55, 50, 50, 'A');
		keys[11] = new Key("S", startX + 75, startY + 55, 50, 50, 'S');
		keys[12] = new Key("D", startX + 125, startY + 55, 50, 50, 'D');
		keys[13] = new Key("F", startX + 175, startY + 55, 50, 50, 'F');
		keys[14] = new Key("G", startX + 225, startY + 55, 50, 50, 'G');
		keys[15] = new Key("H", startX + 275, startY + 55, 50, 50, 'H');
		keys[16] = new Key("J", startX + 325, startY + 55, 50, 50, 'J');
		keys[17] = new Key("K", startX + 375, startY + 55, 50, 50, 'K');
		keys[18] = new Key("L", startX + 425, startY + 55, 50, 50, 'L');

		keys[19] = new Key("Z", startX + 75, startY + 110, 50, 50, 'Z');
		keys[20] = new Key("X", startX + 125, startY + 110, 50, 50, 'X');
		keys[21] = new Key("C", startX + 175, startY + 110, 50, 50, 'C');
		keys[22] = new Key("V", startX + 225, startY + 110, 50, 50, 'V');
		keys[23] = new Key("B", startX + 275, startY + 110, 50, 50, 'B');
		keys[24] = new Key("N", startX + 325, startY + 110, 50, 50, 'N');
		keys[25] = new Key("M", startX + 375, startY + 110, 50, 50, 'M');

		backspace = new Key("Backspace", startX + 225, startY + 170, 200, 50, '.');
	}

	public void draw() {
		for(Key k : keys) {
			k.draw();
		}
		backspace.draw();
	}

	public char mouseEvent(MouseEvent event) {
		for(Key k : keys) {
			if(k.mouseEvent(event)) {
				return k.getLetter();
			}
		}
		if(backspace.mouseEvent(event)) {
			return backspace.getLetter();
		}
		return '_';
	}
};
class MenuButton extends Button {
	
	private State nextState;

	public MenuButton(String t, int x, int y, int w, int h, State nextState) {
		super(t, x, y, w, h);
		this.nextState = nextState;
	}

	public State getNextState() {
		return nextState;
	}
};
/******************************************************************************
 * New Game                                                                   *
 ******************************************************************************/
class NewGameState implements State {
	private Game g;
	private int screen = 0;
	private Button submit;

	//Color Suff
	private Button[] colors;
	private int chosenColor;

	//Name stuff
	private Keyboard keyboard;
	private char[] name;
	private int currentIndex;
	private int maxIndex;
	
	

	public NewGameState(Game g) {
		this.g = g;
		colors = new Button[7];
		keyboard = new Keyboard(75, 100);

		colors[0] = new ColorButton(200, 150, 100, 100, color(255,0,0));
		colors[1] = new ColorButton(300, 150, 100, 100, color(255, 127, 0));
		colors[2] = new ColorButton(400, 150, 100, 100, color(255, 255, 0));
		colors[3] = new ColorButton(150, 250, 100, 100, color(0, 255, 0));
		colors[4] = new ColorButton(250, 250, 100, 100, color(0, 0, 255));
		colors[5] = new ColorButton(350, 250, 100, 100, color(75, 0, 130));
		colors[6] = new ColorButton(450, 250, 100, 100, color(143, 0, 255));

		submit = new  Button("Submit", 300, 550, 100, 50);

		chosenColor = color(255,255,255);

		name = new char[8];

		for (int i = 0; i < 8; i++) {
			name[i] = '_';
		}

		maxIndex = 8;
		currentIndex = 0;
	}

	public void initializeItems() {

	}

	public void draw() {
		background(255);

		switch(screen)
		{
			case 0:
				fill(0);
				writeText("Choose a Color:", width / 2, 50, 28.9f);
				
				for (Button b : colors) {
					b.draw();
				}

				fill(chosenColor);
				rect(width / 2, 400, 100, 100);

				break;

			case 1:
				fill(0);
				writeText("Name your Boxy:", width / 2, 50, 28.9f);
				keyboard.draw();

				fill(0);
				writeText(name, 125, 350, 77.7f);

				break;

			default:
				break;
		}
		submit.draw();		
	}

	public void mouseEvent(MouseEvent event) {
		switch(screen) {
			case 0:
				
				for (Button b : colors) {
					if (b.mouseEvent(event)) {
						chosenColor = ((ColorButton)b).getColor();
					}
				}

				if (submit.mouseEvent(event)) {
					if (chosenColor != color(255,255,255)) {
						g.getBoxy().setColor(chosenColor);
						screen += 1;
					}
				}

				break;

			case 1:
				char k = keyboard.mouseEvent(event);
				if (k == '.') {
					if (currentIndex > 0) {
						currentIndex -= 1;
					}
					name[currentIndex] = '_';
				}
				else if (k != '_') {
					if (currentIndex < maxIndex) {
						name[currentIndex] = k;
						currentIndex += 1;
					}
				}

				if (submit.mouseEvent(event)) {
					if (name[0] != '_') {
						g.getBoxy().setName(name);
						g.setState(g.getInGameState());
					}
				}
				
				break;

			default:
				break;
		}
	}

	public void drag(int x, int y) {
		//Nothing to do.
	}
};
class ShakeState implements BoxyState {

	private Boxy boxy;
	private int left;
	private int right;
	private int stride;
	private int direction;
	private int hitSides;

	public ShakeState(Boxy boxy) {
		this.boxy = boxy;
		stride = -1;
		direction = -1;
		left = (width / 2) - 5;
		right = (width / 2) + 5;
	}

	public void update() {
		boxy.changeX(direction * stride);

		if (boxy.getX() < left) {
			direction *= -1;
			boxy.setPosition(left, boxy.getY());
			hitSides += 1;
		} else if (boxy.getX() > right) {
			direction *= -1;
			boxy.setPosition(right, boxy.getY());
			hitSides += 1;
		} else if (hitSides >= 2 && boxy.getX() <= (width/2)) {
			hitSides = 0;
			boxy.setPosition(width / 2, boxy.getY());
			boxy.setState(boxy.getIdleState());
		}
	}

	public boolean isIdle() {
		return false;
	}
}
class SlideState implements BoxyState {

	private Boxy boxy;
	private int left;
	private int right;
	private int stride;
	private int direction;
	private int hitSides;

	public SlideState(Boxy boxy) {
		this.boxy = boxy;
		direction = -1;
		stride = boxy.getReactionValue() / 10;
		left = (width / 2) - boxy.getReactionValue();
		right = (width / 2) + boxy.getReactionValue();
		hitSides = 0;
	}

	public void update() {
		boxy.changeX(direction * stride);

		if (boxy.getX() < left) {
			direction *= -1;
			boxy.setPosition(left, boxy.getY());
			hitSides += 1;
		} else if (boxy.getX() > right) {
			direction *= -1;
			boxy.setPosition(right, boxy.getY());
			hitSides += 1;
		} else if (hitSides >= 2 && boxy.getX() <= (width/2)) {
			hitSides = 0;
			boxy.setPosition(width/2, boxy.getY());
			boxy.setState(boxy.getIdleState());
		}

		stride = boxy.getReactionValue() / 10;
		left = (width / 2) - boxy.getReactionValue();
		right = (width / 2) + boxy.getReactionValue();
	}

	public boolean isIdle() {
		return false;
	}
}
/******************************************************************************
 * Game States                                                                *
 ******************************************************************************/
interface State {
	public void draw();
	public void initializeItems();
	public void mouseEvent(MouseEvent event);
}
/******************************************************************************
 * Survey                                                                     *
 ******************************************************************************/
class SurveyState implements State {
	private Game g;

	public SurveyState(Game g) {
		this.g = g;
	}

	public void initializeItems() {

	}

	public void draw() {
		link("http://goo.gl/forms/ZhJ8HLMxw4");
		g.setState(g.getTitleState());
	}

	public void mouseEvent(MouseEvent event) {
	}
};
/******************************************************************************
 * Title State                                                                *
 ******************************************************************************/
class TitleState implements State {
	private Game g;
	private Button[] buttons;

	public TitleState(Game g) {
		this.g = g;
		buttons = new Button[4];
	}

	public void initializeItems() {
		buttons[0] = new MenuButton("New Game", width / 2, 150, 300, 50, this.g.getNewGameState());
		buttons[1] = new MenuButton("Load Game", width / 2, 250, 300, 50, this.g.getInGameState());
		buttons[2] = new MenuButton("How To Play", width / 2, 350, 300, 50, this.g.getHowToPlayState());
		buttons[3] = new MenuButton("Take Survey", width / 2, 450, 300, 50, this.g.getSurveyState());
	}

	public void draw() {
		background(255);
		String t = "My Boxy";
		fill(0);

		writeText(t, width / 2, 50, 77.7f);

		for(Button b : buttons) {
			b.draw();
		}
	}

	public void mouseEvent(MouseEvent event) {

		if (buttons[0].mouseEvent(event)) {
			if (random(100) > 50) {
				g.setState(((MenuButton)buttons[0]).getNextState());
			} else {
				g.setState(g.getInGameState());
			}
			
		}

		if (buttons[1].mouseEvent(event)) {
			if(load()) {
				g.setState(((MenuButton)buttons[1]).getNextState());
			}			
		}

		if (buttons[2].mouseEvent(event)) {
			g.setState(((MenuButton)buttons[2]).getNextState());
		}

		if (buttons[3].mouseEvent(event)) {
			g.setState(((MenuButton)buttons[3]).getNextState());
		}
	}

	public boolean load() {
		File f = dataFile("savegame.txt");

		if (f.exists()) {
			String[] lines = loadStrings("savegame.txt");
			String name = lines[0];
			int c = color(PApplet.parseInt(lines[1]));
			int responsiveness = PApplet.parseInt(lines[2]);
			int closeness = PApplet.parseInt(lines[3]);
			int fullness = PApplet.parseInt(lines[4]);
			int happiness = PApplet.parseInt(lines[5]);
			boolean likes = PApplet.parseBoolean(lines[6]);

			g.getBoxy().setName(name);
			g.getBoxy().setColor(c);
			g.getBoxy().setResponsiveness(responsiveness);
			g.getBoxy().setCloseness(closeness);
			g.getBoxy().setFullness(fullness);
			g.getBoxy().setHappiness(happiness);
			g.getBoxy().setLikesPetting(likes);

			return true;
		}

		return false;
	}
};
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "myboxy" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
